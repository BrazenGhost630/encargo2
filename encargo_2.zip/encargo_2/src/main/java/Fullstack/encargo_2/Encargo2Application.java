package Fullstack.encargo_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Encargo2Application {

	public static void main(String[] args) {
		SpringApplication.run(Encargo2Application.class, args);
	}

}
